var socket = io.connect()

socket.on("send_data", (gps_lat, gps_lng, gps_alt, baro_alt, speed, temperature, rssi, snr, data_ser) => {
  document.getElementById("latitude").innerHTML = gps_lat;
  document.getElementById("longitude").innerHTML = gps_lng;
  document.getElementById("altitude").innerHTML = gps_alt;
  document.getElementById("baroAltitude").innerHTML = baro_alt;
  document.getElementById("speed").innerHTML = speed;
  document.getElementById("temperature").innerHTML = temperature;
  document.getElementById("rssi").innerHTML += rssi;
  document.getElementById("snr").innerHTML += snr;
  document.getElementById("rawReceivedData").innerHTML += data_ser;
})

window.onload = function(){
  socket.emit("get_data");

  document.getElementById("pingRequest").addEventListener("click", function() {
    socket.emit("ping_request");
  })
  document.getElementById("dataRequest").addEventListener("click", function() {
    socket.emit("data_request");
  })
  document.getElementById("detachRequest").addEventListener("click", function() {
    socket.emit("detach_request");
  })
  document.getElementById("predictionRequest").addEventListener("click", function() {
    socket.emit("prediction_request");
  })
}