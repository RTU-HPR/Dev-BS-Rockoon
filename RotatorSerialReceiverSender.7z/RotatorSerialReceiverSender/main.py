import serial
from datetime import datetime, timedelta
from time import sleep
import csv
import folium
from flask import Flask, render_template
from flask_socketio import SocketIO

from SondeHubPredictor import GetEstimatedTrajectory

app = Flask(__name__)
app.config["SECRET_KEY"] = "secret!"
app.config['TEMPLATES_AUTO_RELOAD'] = True
socketio = SocketIO(app)

# Define the serial port and baud rate
serial_port = "COM14"
baud_rate = 115200

# csv file name
file_name = "ROTATOR_DATA_"

data_ser = ""
callsign = ""
id = ""
time = ""
gps_lat = ""
gps_lng = ""
gps_alt = ""
temperature = ""
satellites = ""
pressure = ""
speed = ""
baro_alt = ""
rotator_lat = ""
rotator_lng = ""
rotator_alt = ""
rssi = ""
snr = ""

# Balloon flight coordinates
balloon_coordinates = []

# Requests
data_request = False
ping_request = False
detach_request = False

# API
# Last API request time
last_api_request_time = datetime.now()

# Was a prediction requested?
prediction_request = False

# Prediction results
prediction_results = []

@app.route("/")
def index():
    # set the iframe width and height
    # m.get_root().width = "800px"
    # m.get_root().height = "800px"
    # iframe = m.get_root()._repr_html_()

    return render_template("home.html")


@socketio.on("prediction_request")
def handle_prediction_request():
    print("A prediction has been requested!")
    global prediction_request
    prediction_request = True


@socketio.on("data_request")
def handle_data_request():
    print("A data request has been requested!")
    global data_request
    data_request = True


@socketio.on("ping_request")
def handle_ping_request():
    print("A ping request has been requested!")
    global ping_request
    ping_request = True


@socketio.on("detach_request")
def handle_detach_request():
    print("A detach request has been requested!")
    global detach_request
    detach_request = True
    
@socketio.on("get_data")
def handle_get_data():
    socketio.emit("send_data", (gps_lat, gps_lng, gps_alt, baro_alt, speed, temperature, rssi, snr, data_ser))

# Open a new log file
i = 1
while True:
    # Find a file index that does not yet exist
    try:
        file = open(file_name + str(i) + ".csv", "r")
        file.close()
        i += 1
    except:
        # Save the file name to be used
        file_name = file_name + str(i) + ".csv"
        # Write header for csv file
        with open(file_name, "a", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["callsign","id","time","gps_lat","gps_lng","gps_alt","temperature","satellites","pressure","speed","baro_alt","rotator_lat","rotator_lng","rotator_alt","rssi","snr"]
            )
        break

while True:
    # Start the Flask server
    # socketio.run(app, debug=True)
    print("Running")
    # Read data from serial and process it
    try:
        print(f"Connecting to {serial_port}")
        #with serial.Serial(serial_port, baud_rate, timeout=0) as ser:
        while True:
            # Read any available data
            # if ser.in_waiting() > 0:
                # data_ser = ser.read(ser.in_waiting()).decode("utf-8")

                # if "rtu_vip_bfc" in data_ser:
                #     lines = data_ser.split(
                #         "\n"
                #     )  # Guaranteed to have at least 2 entries
                #     data_ser = lines[-2].strip()
                #     print(f"{serial_port} received message: {data_ser}")
            data_ser = "rtu_vip_bfc,3,18:04:43,55.123456,24.987654,123.45,25.67,10,123000,10.5,123.45,15.123456,14.987654,20.52,-50,-2"
            print(data_ser)
            if data_ser:
                data = data_ser.split(",")
                # Split ukhas message + rotator gps position to variables
                (
                    callsign,
                    id,
                    time,
                    gps_lat,
                    gps_lng,
                    gps_alt,
                    temperature,
                    satellites,
                    pressure,
                    speed,
                    baro_alt,
                    rotator_lat,
                    rotator_lng,
                    rotator_alt,
                    rssi,
                    snr,
                ) = data
                print(callsign, id, gps_lat, gps_lng, gps_alt)

                # Log message to file
                with open(file_name, "a", newline="") as f:
                    print("Saving to file")
                    writer = csv.writer(f)
                    writer.writerow(data)
                    
                # Create a map with data
                if float(gps_lat) != 0 and float(gps_lng) != 0:
                    balloon_coordinates.append((float(gps_lat), float(gps_lng)))
                    
                # If no gps coordinates yet available, default to Cēsis airfield
                if balloon_coordinates[-1][0] == 0:
                    # Create a map
                    m = folium.Map((57.320774, 25.322213), zoom_start=11)

                    # Start position
                    folium.Marker(
                        location=(57.320774, 25.322213),
                        tooltip="Starting position",
                        icon=folium.Icon(color="blue"),
                    ).add_to(m)

                    # Save the map
                    m.save("templates/map.html")
                else:
                    # Create a map
                    m = folium.Map(balloon_coordinates[-1], zoom_start=11)

                    # Start position
                    folium.Marker(
                        location=balloon_coordinates[0],
                        tooltip="Starting position",
                        icon=folium.Icon(color="green"),
                    ).add_to(m)

                    # Last balloon position
                    folium.Marker(
                        location=balloon_coordinates[-1],
                        tooltip="Last balloon position",
                        icon=folium.Icon(color="blue"),
                    ).add_to(m)

                    # Balloon trajectory
                    folium.PolyLine(
                        locations=balloon_coordinates,
                        color="#0048ff",
                        weight=5,
                        tooltip="Balloon trajectory",
                    ).add_to(m)

                    # If a prediction was requested and cooldown time has passed
                    seconds = (datetime.now() - last_api_request_time).total_seconds()
                    print(seconds, prediction_request)
                    if (prediction_request and seconds > 60):
                        prediction_request = False
                        last_api_request_time = datetime.now()
                        if balloon_coordinates[-1][0] != 0:
                            prediction_results = GetEstimatedTrajectory(
                                float(gps_lat),
                                float(gps_lng),
                                float(gps_alt),
                                ascent_rate=6,
                                burst_altitude=gps_alt + 10,
                                descent_rate=6,
                            )
                            print(prediction_results)
                        if prediction_results:
                            print("Prediction requested successfully!")
                                

                    # If prediction result isn't empty, add it to the map
                    if prediction_results:
                        # Prediction start position
                        folium.Marker(
                            location=(
                                prediction_results[0][-2],
                                prediction_results[0][-1],
                            ),
                            tooltip="Prediction burst position",
                            icon=folium.Icon(color="red"),
                        ).add_to(m)

                        # Last Prediction position
                        folium.Marker(
                            location=(
                                prediction_results[-1][-2],
                                prediction_results[-1][-1],
                            ),
                            tooltip="Prediction landing position",
                            icon=folium.Icon(color="blue"),
                        ).add_to(m)

                        # Prediction trajectory
                        folium.PolyLine(
                            locations=[
                                [x[-2], x[-1]] for x in prediction_results
                            ],
                            color="#FF0000",
                            weight=3,
                            tooltip="Prediction trajectory",
                        ).add_to(m)
                    # Save the map
                    m.save("templates/map.html")

                    socketio.emit("send_data", (gps_lat, gps_lng, gps_alt, baro_alt, speed, temperature, rssi, snr, data_ser))
                # else:
                #     print(f"{serial_port} received a different message: {data_ser}")

    except serial.SerialException as err:
        print(f"Connection failed with error: {err.args}")
        print("Reconnecting...")
        sleep(1)
    except KeyboardInterrupt:
        break